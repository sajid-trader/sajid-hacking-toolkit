# Sajid Hacking Toolkit
Custom toolkit designed for ethical hacking on Termux (rootless Android). Includes scripts for sqlmap, nmap, hydra, and more.
