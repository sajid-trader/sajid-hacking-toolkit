#!/bin/bash
echo "Installing Sajid Hacking Toolkit..."
mkdir -p $HOME/.sajidtoolkit/logs
cp -r tools $HOME/.sajidtoolkit/
echo "Installation complete." >> $HOME/.sajidtoolkit/logs/install_log.txt
echo "Toolkit installed successfully."
