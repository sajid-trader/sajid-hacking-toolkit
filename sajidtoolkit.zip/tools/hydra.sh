#!/bin/bash
pkg install -y hydra
hydra "$@"
