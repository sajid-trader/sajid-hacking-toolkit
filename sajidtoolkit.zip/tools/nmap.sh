#!/bin/bash
pkg install -y nmap
nmap "$@"
