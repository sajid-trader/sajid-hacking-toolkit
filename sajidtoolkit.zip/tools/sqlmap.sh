#!/bin/bash
pkg install -y python git
git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git $HOME/sqlmap
cd $HOME/sqlmap
python sqlmap.py "$@"
