#!/bin/bash
pkg install -y python git
git clone https://github.com/maurosoria/dirsearch.git $HOME/dirsearch
cd $HOME/dirsearch
python3 dirsearch.py "$@"
